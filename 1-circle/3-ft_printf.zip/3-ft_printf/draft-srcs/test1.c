/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test1.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: codespace <codespace@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/17 11:47:43 by codespace         #+#    #+#             */
/*   Updated: 2024/10/31 11:23:57 by codespace        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <limits.h>


// cc -g -Wall -Wextra -Werror test1.c
int	main(void)
{
	char	A = 'A';
	char	*name = "Alex";
	char	*last;
	int		x = 16;

	// |         A|
	// |     hello|
	// printf("|%10c|\n", A);
	// printf("|%-10c|\n", A);
	printf("|%10.s|\n", "hello");
	printf("|%-10.s|\n", "hello");

	printf("|%10.2c|\n", A);
	printf("|%-10.2c|\n", A);

	// printf("Hello %%12d% love!\n", x);
	// printf("Hello %-3.01s love!\n", name);
	// printf("Hello %-3.2ks love!\n", name);
	// printf("Hello %-3.s love!\n", name);
	// printf("Hello %-3.2s love!\n", name);
	// printf("Hello %-.2s love!\n", name);
	// printf("Hello %12d% love!\n", INT_MAX);
	// printf("INT_MAX = %2147483631d %d\n", x, x);
	// printf("INT_MIN = %d\n", INT_MIN);
	// printf("with %%--++dlove: %--++ love\n", 42);
	// printf("with %%-dlove: %-dlove\n", 42);
	// printf("with %%--++4dlove: %--++4dlove\n", 42);
	// printf("with %%-4dlove: %04dlove\n", 424);
	// printf("Hello %-+12c love!\n", A);
	// printf("Hello %-+-0-+12c love %s!\n", name, A, name);
	// printf("Hello %-+-0-+12c love %s!\n", name, A, name);
	// printf("Hello %-2+-0-+12c love %s!\n", A, name); // segfault;
	// printf("Hello %----12c %-5% Love!\n", A);
	// printf("%-5c Hello, %wc perferct\n", 42, 42);
	// write(1, name+3, 1);
	// write(1, "\n", 1);
	// write(1, name, 2);
	// write(1, "\n", 1);
	//printf("hello %s"+name+" :)");
	return (0);
}
