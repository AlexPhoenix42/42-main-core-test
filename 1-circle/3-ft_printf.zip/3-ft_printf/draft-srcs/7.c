/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   7.c                                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: codespace <codespace@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/31 10:07:58 by codespace         #+#    #+#             */
/*   Updated: 2024/10/31 20:12:28 by codespace        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>
#include <stdlib.h>
#include <errno.h>

// https://manp.gs/mac/3/printf
// https://manp.gs/mac/3/stdarg

// My ft_printf() just broke the system.
// I dont know how is it bypassing the system's
// security out of bounds check!!!!
// My ft_printf() can read beyond the allowed memory!!!!

// cc -g -O0 -Wall -Wextra -Werror 7.c
// valgrind --leak-check=full --track-origins=yes --show-leak-kinds=all ./a.out

int	ft_printf(const char *, ...);
//static size_t	ft_printnstr(const char *str, va_arg(args, void*), size_t n);

typedef struct	form_found
{
	size_t	i;
	char	*is_found;
	char	flags[6];
	char	form;
	int		width;
	int		precision;
} printf_form;

static char *ft_print_char(char *str, char **ptr, size_t *len_r, ssize_t n);
static void	get_form(char *str, char *flags, char *forms,
						printf_form *form_found);
int	string2int(char *str, int sign);
static int	process_arg(va_list args, char **str, printf_form *form_found, size_t *len_r);
// static void print_arg(const char *form_found, size_t *len_r);
// static size_t	ft_printnstr(const char *str, va_list args, size_t n);
static void	*ft_memchr(char *s, int c, size_t n);
// static size_t	ft_strlen(const char *str);
// static size_t	ptr_abs(ssize_t n);
static int	ft_isdigit_pls(int c);
int	ft_isdigit(int c);
char	*ft_strchr(const char *s, int c);

static void	init_printf_form(printf_form *form_found, char *is_found);


int	ft_printf(const char *str0, ...)
{
	// size_t	i;
	size_t	len_r;
	char	*ptr;
	// char	*form_found;
	printf_form	form_found;
	va_list	args;
	va_list	args_cpy;
	char	*str;
	str = malloc(strlen(str0) * sizeof(char));
	memcpy(str, str0, strlen(str0) + 1);	// you have to add +1 to copy the '\0' from str0 to str;

	va_start(args, str0);
	va_copy(args_cpy, args);
	init_printf_form(&form_found, NULL);
	len_r = 0;
	form_found.is_found = ft_print_char(str, &ptr, &len_r, -1);
	while (form_found.is_found)
	{
		get_form(ptr+1, "-0#. +", "cspdiuxX%", &form_found);
		if (!(process_arg(args_cpy, &ptr, &form_found, &len_r)))
			return (-1);
		if (form_found.is_found)
		{
			while (ft_memchr("cspdiuxX%", *ptr, 9) != NULL)
				++ptr;
			// ft_strlen(form_found) + 2;
			// print_arg(form_found, &len_r);
			// free(form_found);
			init_printf_form(&form_found, NULL);
		}
		// ++ptr;
		if (errno)
			return (-1);
		form_found.is_found = ft_print_char(ptr, &ptr, &len_r, -1);
	}
	free(str);
	return ((int) len_r);	// this is to be fixed
}

/*
	These functions return the number of characters printed (not including
	the trailing `\0' used to end output to strings) or a negative value if
	an output error occurs, except for snprintf() and vsnprintf(), which
	return the number of characters that would have been printed if the n
	were unlimited (again, not including the final `\0').
*/

static void	init_printf_form(printf_form *form_found, char *is_found)
{
	form_found->i = 0;
	form_found->is_found = is_found;
	memcpy(form_found->flags, (char[]){1, 1 , 1 , 1 , 1, 0}, 6);
	form_found->form = '\0';
	form_found->width = 0;
	form_found->precision = 0;
}

// static char *ft_print_char(int c, char *form_found)
static char *ft_print_char(char *str, char **ptr, size_t *len_r, ssize_t n)
{
	size_t	i;
	// char	*form_found;

	errno = 0;
	i = -1;
	while (str[++i] != '\0')
	{
		if (str[i] == '%')
		{
			*ptr = &(str[i]);
			return (*ptr);
		}
		if (n == -1 || (n > 0 && i < n))
			*len_r += write(1, &(str[i]), 1);
		if (errno)
			return (NULL);
	}
	return (NULL);
}

// General Format of a printf() Format Specifier:
// A valid format specifier has the following general structure:

// %[flags][width][.precision][length modifier]conversion specifier
// Key Point:
// The field width specifies the minimum number of characters to be
// printed, and it is followed immediately by either the precision
// (if applicable) or the conversion specifier.
static void	get_form(char *str, char *flags, char *forms,
						printf_form *form_found)	// I have to teat 'form_found' as a void array to safely store string and width as int!!!!
{
	size_t	i;
	char	*width;
	char	*precision;
	// flags: "-0.# +",
	// forms: "cspdiuxX%"

	width = NULL;
	precision = NULL;
	i = -1; // we skip the first one because we want to skip %; // this comment is not valid!!!
	if (ft_memchr(forms, str[0], 6) != NULL)
	{
		form_found->form = str[0];
	}
	else
	while ((ft_memchr(flags, str[++i], 6) != NULL) || ft_isdigit_pls(str[i]))
	{
		if ((form_found->i) < 5 && (ft_memchr(flags, str[i], 6) != NULL) && ft_memchr(form_found->flags, str[i], 5) == NULL)
		{
			++(form_found->i);
			(form_found->flags)[form_found->i] = str[i];
		}
		if (!width && !ft_isdigit_pls(str[i - 1]) && ft_isdigit_pls(str[i])) // we can do i - 1 because we are skiping i = 0; We are not skiping i = 0 anymore so I need to check this!!!!
			width = str+i;
		if (!precision && str[i] == '.')
			precision = &(str[i]);
		if ((ft_memchr(forms, str[i + 1], 9) != NULL))
		{
			form_found->form = str[i + 1];	// the form "cspdiuxX%" that would be used;
			if (width)
				form_found->width = string2int(width, 1);
			if (precision)
				form_found->precision = string2int(precision+1, 1);
			break;
		}
		// if ((width || precision) && ft_isdigit(str[i]) && !ft_isdigit_pls(str[i + 1]))
		if ((width || precision) && ft_isdigit(str[i]) && !ft_isdigit(str[i + 1]))
			if (width && str[i + 1] != '.' )
				break;
	}
}

int	ft_isdigit(int c)
{
	unsigned char	uc;

	if (c == EOF)
		return (0);
	uc = (unsigned char) c;
	if ('0' <= uc && uc <= '9')
		return (1);
	return (0);
}

int	string2int(char *str, int sign)
{
	size_t	i;
	long	x;

	if (!str)
		return (0);
	x = 0;
	i = -1;
	while ('0' <= str[++i] && str[i] <= '9')
	{
		x = (x * 10) + (str[i] - '0');
		if (x >= INT_MAX)
			return (INT_MAX);
		if (x <= INT_MIN)
			return (INT_MIN);
	}
	return (x * sign);
}

static int	process_arg(va_list args, char **str, printf_form *form_found, size_t *len_r)
{
	// char	*ptr;
	char	cs[2];
	size_t	i;
	size_t	j;

	i = -1;
	j = -1;
	// ptr = form_found;
	if (form_found->form == 'c')
	{
		int c = va_arg(args, int);
		cs[0] = (char) c;
		cs[1] = '\0';
		if (form_found->width && ft_memchr(form_found->flags, '-', 5) == NULL)
			while (++j < (size_t) form_found->width - 1)
				*len_r += write(1, ".", 1);	// form_found[] must be an int to handle width not char!!!!1
		ft_print_char(cs, str, len_r, 1);
		*str = ft_strchr((const char*) (*str), (int) 'c') + 1;
		if (ft_memchr(form_found->flags, '-', 5))	// '-' is not recorded inside 'form_found'! Needs to be fixed!
			while (++j < (size_t) form_found->width - 1)
				*len_r += write(1, ".", 1);	// form_found[] must be an int to handle width not char!!!!1
		return (1);
	}
	if(form_found->form == 's')
	{
		char *s = va_arg(args, char *);
		// while (s[++i] != '\0')	// you dont need this because ft_print_char actually do that!!!
		if (form_found->width && ft_memchr(form_found->flags, '-', 5) == NULL)
			while (++j < (size_t) form_found->width + form_found->precision - strlen(s))
				*len_r += write(1, ".", 1);	// form_found[] must be an int to handle width not char!!!!1
		ft_print_char(&(s[++i]), str, len_r, form_found->precision);
		*str = ft_strchr((const char*) (*str), (int) 's') + 1;
		if (ft_memchr(form_found->flags, '-', 5))	// '-' is not recorded inside 'form_found'! Needs to be fixed!
			while (++j < (size_t) form_found->width + form_found->precision - strlen(s))
				*len_r += write(1, ".", 1);	// form_found[] must be an int to handle width not char!!!!1
		return (1);
	}
	if (form_found->form == '\0')
	{
		ft_print_char(*str, str, len_r, -1);
		return (1);
		// *str = ft_strchr((const char*) (*str), (int) 's') + 1;
	}
	return (0);
}

char	*ft_strchr(const char *s, int c)
{
	size_t	i;

	i = -1;
	while (s[++i] != '\0')
		if (s[i] == (char) c)
			return ((char *) (s + i));
	if ((char) c == '\0')
		return ((char *) (s + i));
	return (NULL);
}

// static void print_arg(const char *form_found, size_t *len_r)
// {
// 	size_t	i;

// 	errno = 0;
// 	i = -1;
// 	while (form_found[++i] != '\0')
// 		*len_r += write(1, &(form_found[i]), 1);
// }

// static size_t	ft_printnstr(const char *str, va_list args, size_t n)
// {
// 	size_t	strlen;

// 	size_t	len_r;

// 	strlen = ft_strlen(str);
// 	len_r = write(1, str, n);
// 	if (len_r < strlen)
// 		return (-1);
// 	return (len_r);
// }

/*
static void	*get_arg(va_list args, char *form_found)
{
	if (form_found[0] == 'c')
		return (va_arg(args, int));
}

static char	*cpy_line(char **line, const char *src, size_t n)
{
	size_t	i;
	size_t	j;
	char	*str;

	if (!line || !src)
		return (NULL);
	str = (char *) malloc((n + 1) * sizeof(char));
	if (!str)
		return (NULL);
	i = -1;
	if (*line)
	{
		while ((*line)[++i] != '\0')
			str[i] = (*line)[i];
		str[i] = '\0';
		free(*line);
		--i;
	}
	j = -1;
	while (++i < n)
		str[i] = src[++j];
	str[i] = '\0';
	*line = str;
	return (*line);
}

int base2int(char *str, char *base, unsigned int baselen, int sign)
{
    unsigned int    i;
    unsigned int    j;
    unsigned int    t;
    int             nbr;

    nbr = 0;
    i   = -1;
    while (str[++i] != '\0')
    {
        t = 0;
        j = -1;
        while (base[++j] != '\0')
        {
            if (str[i] == base[j])
            {
                nbr = (nbr * baselen) + (j);
                t   = 1;
                break ;
            }
        }
        if (t == 0)
            return (nbr * sign);
    }
    return (nbr * sign);
}
*/

static void	*ft_memchr(char *s, int c, size_t n)
{
	size_t	i;

	i = -1;
	while (++i < n)
		if (((unsigned char *) s)[i] == (unsigned char) c)
			return (s + i);
	return (NULL);
}

// static size_t	ft_strlen(const char *str)
// {
// 	size_t	strlen;
// 	strlen = 0;
// 	while (str[strlen] != '\0')
// 		strlen++;
// 	return (strlen);
// }

// static size_t	ptr_abs(ssize_t n)
// {
// 	if (n < 0)
// 		return (-n);
// 	return ((size_t) n);
// }

static int	ft_isdigit_pls(int c)
{
	unsigned char	uc;

	if (c == EOF)
		return (0);
	uc = (unsigned char) c;
	if ('1' <= uc && uc <= '9')
		return (1);
	return (0);
}





int main(void)
{
	char	c = 'A';
	char	*name = "Alex";

	// ft_printf("|%-10.2c|\n", A);
	// printf("|%-10.2c|\n", A);

	ft_printf("|%10.2s|\n", name);
	printf("|%10.2s|\n", name);
	// ft_printf("Hello %c :) %c\n", name, name);
	// ft_printf("Hello %-5kc my name is %k2.s :)\n", c, name);
	// ft_printf("Hello %-k5c my name is %2k.s :)\n", c, name);
	// ft_printf("Hello %-5c my name is %k2.s :)\n", c, name);
	// ft_printf("Hello %-5c my name is %2.ks :)\n", c, name);
	// ft_printf("Hello %s :)\n", c);
	// ft_printf("Hello %c :) %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c \n", name, name);
	// ft_printf("Hello %d :)\n", name, name);
	return (0);
}
