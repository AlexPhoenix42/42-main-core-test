/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test2.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: codespace <codespace@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/31 12:06:22 by codespace         #+#    #+#             */
/*   Updated: 2024/11/01 14:17:24 by codespace        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <limits.h>

static size_t	getintlen(int x);

// cc -g -Wall -Wextra -Werror test1.c
int	main(void)
{
	// float x = 16.5;
	// size_t	intlen;

	// printf("%+5d\n", 12345);	// → Output: +12345
	// printf("%+3d\n", 12345);	// → Output: +12345
	// printf("%+3d\n", 12345);	// → Output: 12345 (no +)
	// printf("%+1d\n", 5);		// → Output: 5 (no +)
	// printf("%+3d\n", 5);		// → Output: +5

	// printf("number = |%-02.3d|\n", 9);
	// printf("number = |%-02.3d|\n", 19);

	// printf("number = |%3.2d|\n", 9);
	// printf("number = |%-0d|\n", 19);

	// printf("|%08.5d|\n", 42);	// |   00042|
	// printf("|%0.5d|\n", 42);
	// printf("|%+2.5d|\n", 42);
	// printf("|%+ .5d|\n", 42);

	// printf("|%2.5d|\n", 42);	// |00042|
	// printf("|% 8.5d|\n", 42);	// |   00042|
	// printf("|%8.5d|\n", 42);	// |   00042|
	// printf("|% .5d|\n", 42);	// | 00042|
	// printf("|% 3.5d|\n", 42);	// | 00042|
	// printf("|%+- 8.5d|\n", 42);	// |+00042  |
	// printf("|%- 8.5d|\n", 42);	// | 00042  |
	// printf("|%-8.5d|\n", 42);	// |00042   |

	printf("|%0.5d|\n", 123456789);	// |123456789|
	printf("|%09.5d|\n", 123456);	// |   123456|
	printf("|%09d|\n", 123456);		// |000123456|
	printf("|%09.d|\n", 123456);	// |   123456|
	printf("|%09.0d|\n", 123456);	// |   123456|

	// intlen = getintlen(1235.2);
	// printf("intlen = %ld\n", intlen);
	// printf("number = %d\n", 16.5);
	// printf("number = %i\n", 16.5);

	// printf("number = %d\n", x);
	// printf("number = %i\n", x);

	// printf("number = %d\n", 'a');
	// printf("number = %i\n", 'a');

	return (0);
}

static size_t	getintlen(int x)
{
	size_t	i;

	i = 0;
	while (x != 0)
	{
		i++;
		x /= 10;
	}

	return (i);
}
