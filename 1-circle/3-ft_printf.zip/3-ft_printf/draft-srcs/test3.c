/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test3.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: codespace <codespace@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/02 09:34:05 by codespace         #+#    #+#             */
/*   Updated: 2024/12/10 17:37:27 by codespace        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <limits.h>

static size_t	getintlen(int x);

// cc -g -Wall -Wextra -Werror test3.c

int	main(void)
{
	int	var = 42;

	printf("%%x: %x\n", -13);
	printf("%%x: %x\n", 0x1A3);
	printf("|%-025p|\n", &var);

	printf("%u\n", INT_MAX);
	printf("%d\n", INT_MAX);
	printf("%u\n", INT_MIN);
	printf("%d\n", INT_MIN);

	return (0);
}

/*
int	main(void)
{
	// float x = 16.5;
	// size_t	intlen;

	// printf("Test 11: %%05d with 123: |%05d|\n", 123);     // Expected: |00123|	bad
    // printf("Test 12: %%05d with -123: |%05d|\n", -123);   // Expected: |-0123|	bad

	// printf("Test 23: %%+d with 0: |%+d|\n", 0);           // Expected: |+0|
    // printf("Test 24: %% d with 0: |% d|\n", 0);           // Expected: | 0|
    // printf("Test 25: %%05d with 0: |%05d|\n", 0);         // Expected: |00000|

	// printf("Test 11: %%05d with 0: |%05d|\n", 0);     // Expected: |00123|	bad
	// printf("Test 25: %%05d with 0: |%05d|\n", 0);         // Expected: |00000|

	// printf("Test 14: %%-d with -123: |%-d|\n", 123);
	// printf("Test 14: %%-d with -123: |%-d|\n", -123);

	// printf("Test 20: %%.5d with -123: |%.5d|\n", -123);   // Expected: |-00123|
	// printf("|%.6d|\n", 123);  // Output: | 123| (width 5, precision 3, int_len 3) |  123|
	// printf("|% 5d|\n", 123);	// |  123|
	// printf("|% .d|\n", 0);
	// printf("|%d|\n", 0);

	// printf("Test 12: %%05d with -123: |% 05d|\n", -123);
	// printf("Test 12: %%05d with -123: |% d|\n", -123);
	// printf("Test 12: %%05d with -123: |% d|\n", 123);
	// printf("Test 12: %%05d with -123: |%0d|\n", -123);
	// printf("Test 12: %%05d with -123: |% 0d|\n", 1);
	// printf("Test 12: %%05d with -123: |%0d|\n", 1);
	// printf("|% .7d|\n", 0);

	// ft_printf("Test 11: %%05d with 123: |% 05d|\n", 123);     // Expected: |00123| // bad
    printf("Test 11: %%05d with 123: |% 05d|\n", 123);     // Expected: |00123|
	printf("Test 11: %%05d with 123: |% 05d|\n", -123);     // Expected: |00123|
	printf("Test 11: %%05d with 123: |% +05d|\n", 123);     // Expected: |00123|
	printf("Test 11: %%05d with 123: |% 05d|\n", 0);     // Expected: |00123|
	printf("Test 11: %%05d with 123: |%05d|\n", 0);     // Expected: |00123|




	return (0);
}
*/

	// if (form_found->form == 'd' || form_found->form == 'i')
	// {
	// 	int	x = va_arg(args, int);
	// 	size_t	int_len = getintlen(x);
	// 	size_t	is_negative;

	// 	is_negative = 0;
	// 	if (x < 0)
	// 		is_negative = 1;
	// 	if (flags[5] == '.' || form_found->width != 0)
	// 	{
	// 		if (form_found->precision <= int_len)
	// 		{
	// 			if (form_found->width <= int_len && flags[1] != '+' && flags[3] == ' ')
	// 				*len_r += write(1, " ", 1);
	// 			if (form_found->width > int_len && flags[0] != '-')
	// 				while (++j < form_found->width - int_len - (is_negative | flags[1] / '+'))
	// 					*len_r += write(1, " ", 1);
	// 			if (x < 0)
	// 				*len_r += write(1, "-", 1);
	// 			if (x > 0 && flags[1] == '+')
	// 				*len_r += write(1, "+", 1);
	// 			if (x != 0)
	// 				*len_r += wint2base(x, "0123456789", 10);
	// 			else
	// 			if (form_found->precision == 0)
	// 				len_r += write(1, "", 1);
	// 			else
	// 			if (form_found->precision != 0)
	// 				len_r += write(1, "0", 1);
	// 			if (form_found->width > int_len && flags[0] == '-')
	// 				while (++j < form_found->width - int_len - (is_negative | flags[1] / '+'))
	// 					*len_r += write(1, " ", 1);
	// 		}
	// 		else
	// 		if (form_found->precision > int_len)
	// 		{
	// 			if (form_found->width > form_found->precision && flags[0] != '-')
	// 				while (++j < form_found->width - form_found->precision - (is_negative | flags[1] / '+'))
	// 					*len_r += write(1, " ", 1);
	// 			if (x < 0)
	// 				*len_r += write(1, "-", 1);
	// 			if (x > 0 && flags[1] == '+')
	// 				*len_r += write(1, "+", 1);
	// 			if (flags[1] != '+' && flags[3] == ' ')
	// 				*len_r += write(1, " ", 1);
	// 			while (++j < form_found->precision - int_len)
	// 				*len_r += write(1, "0", 1);
	// 			if (x != 0)
	// 				*len_r += wint2base(x, "0123456789", 10);
	// 			else
	// 			if (form_found->precision == 0)
	// 				len_r += write(1, "", 1);
	// 			else
	// 			if (form_found->precision != 0)
	// 				len_r += write(1, "0", 1);
	// 			if (form_found->width > form_found->precision && flags[0] == '-')
	// 				while (++j < form_found->width - form_found->precision - (is_negative | flags[1] / '+'))
	// 					*len_r += write(1, " ", 1);
	// 		}
	// 	}
	// 	else
	// 		{
	// 		if (x > 0 && flags[3] == ' ' && flags[1] != '+')
	// 			*len_r += write(1, " ", 1);
	// 		if (x > 0 && ((flags[1] == '+') || (flags[1] == '+' && flags[3] == ' ')))
	// 			*len_r += write(1, "+", 1);
	// 		if (x == 0)
	// 			len_r += write(1, "0", 1);
	// 		*len_r += wint2base(x, "0123456789", 10);
	// 	}
	// }






















// if (form_found->form == 'd' || form_found->form == 'i')
// {
// 	int	x = va_arg(args, int);
// 	size_t	int_len = getintlen(x);

// 	if (flags[5] == '.' || form_found->width != 0)
// 	{
// 		if (form_found->precision <= int_len)
// 		{
// 			if (form_found->width <= int_len && flags[1] != '+' && flags[3] == ' ')
// 				*len_r += write(1, " ", 1);
// 			if (form_found->width > int_len && flags[0] != '-')
// 				while (++j < form_found->width - int_len - (is_negative | flags[1] / '+'))
// 					*len_r += write(1, " ", 1);
// 			*len_r += int_printf_logic(form_found, int_len, len_r, x);
// 		}
// 		else
// 		if (form_found->precision > int_len)
// 		{
// 			if (form_found->width > form_found->precision && flags[0] != '-')
// 				while (++j < form_found->width - form_found->precision - (is_negative | flags[1] / '+'))
// 					*len_r += write(1, " ", 1);
// 			*len_r += int_printf_logic(form_found, int_len, len_r, x);
// 		}
// 	}
// 	else
// 		{
// 		if (x > 0 && flags[3] == ' ' && flags[1] != '+')
// 			*len_r += write(1, " ", 1);
// 		if (x > 0 && ((flags[1] == '+') || (flags[1] == '+' && flags[3] == ' ')))
// 			*len_r += write(1, "+", 1);
// 		if (x == 0)
// 			len_r += write(1, "0", 1);
// 		*len_r += wint2base(x, "0123456789", 10);
// 	}
// }


// size_t	int_printf_logic(print_form *form_found, size_t int_len, char *flags, int x)
// {
// 	size_t	j;
// 	size_t	len_r;
// 	size_t	is_negative;

// 	is_negative = 0;
// 	if (x < 0)
// 		is_negative = 1;
// 	len_r = 0;
// 	j = -1;
// 	if (x < 0)
// 		len_r += write(1, "-", 1);
// 	if (x > 0 && flags[1] == '+')
// 		len_r += write(1, "+", 1);
// 	if (form_found->precision > int_len)
// 	{
// 		if (flags[1] != '+' && flags[3] == ' ')
// 			len_r += write(1, " ", 1);
// 		while (++j < form_found->precision - int_len)
// 			len_r += write(1, "0", 1);
// 	}
// 	if (x != 0)
// 		len_r += wint2base(x, "0123456789", 10);
// 	else
// 	if (form_found->precision == 0)
// 		len_r += write(1, "", 1);
// 	else
// 	if (form_found->precision != 0)
// 		len_r += write(1, "0", 1);
// 	if (form_found->width > int_len && flags[0] == '-')
// 		while (++j < form_found->width - int_len - (is_negative | flags[1] / '+'))
// 			len_r += write(1, " ", 1);
// 	return (len_r);
// }

static size_t	getintlen(int x)
{
	size_t	i;

	i = 0;
	while (x != 0)
	{
		i++;
		x /= 10;
	}

	return (i);
}
