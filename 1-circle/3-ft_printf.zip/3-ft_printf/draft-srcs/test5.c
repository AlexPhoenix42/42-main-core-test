#include <stdio.h>

// int array_add (int array1[], int array2[], int result[], int length);

int main() {
    int arr[] = {10, 1, 2};
    int arr2[] = {1, 3, 3};
    int result[] = {0, 1, 1};
    // array_add(arr, arr2, result, 3);
    for (int index = 0; index < 3; index = index + 1) {
        printf("%d\n", result[index]);
        fflush(stdout);        //  Flush the stream.
    }
}
