/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_int_printf.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: codespace <codespace@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/11 08:56:32 by codespace         #+#    #+#             */
/*   Updated: 2024/12/12 08:22:25 by codespace        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include "ft_printf_lib.h"
#include <stdlib.h>
#include <stdarg.h>

#define WIDTH		form_found->width
#define PERCISION	form_found->precision
#define BOOL1		flags[3] == ' ' && x >= 0 && flags[1] != '+'
#define BOOL2		j < WIDTH - int_len - ((x < 0) | \
					flags[1] / '+' | flags[3] / ' ')
#define LOGIC		(flags[3] / ' ') & (!(flags[2] / '0'))) | \
					((flags[3] / ' ') & (flags[2] / '0')
#define BOOL3		(x < 0) | flags[1] / '+'
#define BOOL4		(BOOL3 | flags[3] / ' ')


size_t	int_printf(va_list args, printf_form *form_found,
					char *flags, char **str);
size_t	int_printf_logic0(printf_form *form_found, size_t int_len,
							char *flags, int x);
size_t	int_printf_logic(printf_form *form_found, size_t int_len,
							char *flags, int x);
size_t	int_printf_logic_prefix(printf_form *form_found, size_t int_len,
							char *flags, int x);
size_t	int_printf_logic_prefix0(printf_form *form_found, size_t int_len,
									char *flags, int x);

size_t	int_printf(va_list args, printf_form *form_found,
					char *flags, char **str)
{
	int	x;
	size_t	int_len;
	size_t	len_r;

	x = va_arg(args, int);
	int_len  = getintlen(x);
	len_r = 0;
	if (flags[5] == '.' || WIDTH != 0)
		len_r += int_printf_logic0(form_found, int_len, flags, x);
	else
	{
		if (BOOL1 && (WIDTH >= int_len || !WIDTH))
			len_r += write(1, " ", 1);
		len_r += int_printf_logic(form_found, int_len, flags, x);
	}
	if (form_found->form == 'd')
		*str = ft_strchr((const char*) (*str), (int) 'd') + 1;
	else
		*str = ft_strchr((const char*) (*str), (int) 'i') + 1;
	return (len_r);
}

size_t	int_printf_logic0(printf_form *form_found, size_t int_len,
							char *flags, int x)
{
	size_t	len_r;
	size_t	j;

	len_r = 0;
	j = -1;
	if (flags[5] == '.' && PERCISION <= int_len)
	{
		if (WIDTH <= int_len && flags[1] != '+' && flags[3] == ' ')
			len_r += write(1, " ", 1);
		if (WIDTH > int_len && flags[0] != '-')
			while (++j < WIDTH - int_len - (BOOL3))
				len_r += write(1, " ", 1);
		len_r += int_printf_logic(form_found, int_len, flags, x);
	}
	else
	if (flags[5] == '.' && PERCISION > int_len)
	{
		if (WIDTH > PERCISION && flags[0] != '-')
			while (++j < WIDTH - PERCISION - (BOOL3))
				len_r += write(1, " ", 1);
		len_r += int_printf_logic(form_found, int_len, flags, x);
	}
	else
		len_r += int_printf_logic(form_found, int_len, flags, x);
	return (len_r);
}

size_t	int_printf_logic(printf_form *form_found, size_t int_len,
							char *flags, int x)
{
	size_t	j;
	size_t	len_r;

	len_r = 0;
	len_r += int_printf_logic_prefix(form_found, int_len, flags, x);
	if (x != 0)
		len_r += wint2base_minus(x, "0123456789", 10);
	else	// |    |	|     |
	if (PERCISION == 0 && WIDTH == 0 && flags[5] == '.')
		len_r += write(1, "", 1);
	else	// |    |	|     |
	if (PERCISION == 0 && WIDTH != 0 && flags[5] == '.')
		len_r += write(1, " ", 1);
	else
		len_r += write(1, "0", 1);
	j = -1;
	if (WIDTH > int_len && flags[0] == '-')
		while (++j < WIDTH - int_len - (BOOL3))
			len_r += write(1, " ", 1);
	return (len_r);
}

size_t	int_printf_logic_prefix(printf_form *form_found, size_t int_len,
							char *flags, int x)
{
	size_t	j;
	size_t	len_r;

	len_r = 0;
	j = -1;
	len_r += int_printf_logic_prefix0(form_found, int_len, flags, x);
	if (x < 0)
		len_r += write(1, "-", 1);
	if (x >= 0 && flags[1] == '+')
		len_r += write(1, "+", 1);
	if (flags[5] == '.' && PERCISION > int_len)
	{
		if (flags[1] != '+' && flags[3] == ' ')
			len_r += write(1, " ", 1);
		while (++j < PERCISION - int_len)
			len_r += write(1, "0", 1);
	}
	if (flags[5] != '.' && flags[0] != '-' && (WIDTH >= int_len || !WIDTH))
	{
		if (flags[2] == '0' && WIDTH)
			while ((!++j && WIDTH) || BOOL2)
				len_r += write(1, "0", 1);
	}
	return (len_r);
}

size_t	int_printf_logic_prefix0(printf_form *form_found, size_t int_len,
									char *flags, int x)
{
	size_t	j;
	size_t	len_r;
	char	logic;
	char	logic2;

	logic = 0;
	len_r = 0;
	if (flags[5] != '.' && flags[0] != '-' && WIDTH >= int_len)
	{
		logic = (LOGIC);
		logic2 = (logic & (flags[1] != '+')) & ((logic & (x >= 0)));
		if (logic2 && x > 0 && flags[1] != '+' && flags[2] != '0')
			len_r += write(1, " ", 1);
		j = -1;
		while ((logic2) && ++j < WIDTH - int_len - BOOL4 && WIDTH >= int_len)
				len_r += write(1, " ", 1);
		j = -1;
		if (!logic2 && WIDTH && flags[2] != '0')
			while (++j < WIDTH - int_len - (BOOL3) && WIDTH >= int_len)
				len_r += write(1, " ", 1);
	}
	return (len_r);
}
