/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf copy.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: codespace <codespace@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/07 11:06:10 by codespace         #+#    #+#             */
/*   Updated: 2024/12/15 07:23:22 by codespace        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./includes/libft.h"
#include "./includes/ft_printf_lib.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>
#include <stdlib.h>
#include <stdarg.h>
#include <errno.h>
#include <stdint.h>

// https://manp.gs/mac/3/printf
// https://manp.gs/mac/3/stdarg

// My ft_printf() just broke the system.
// I dont know how is it bypassing the system's
// security out of bounds check!!!!
// My ft_printf() can read beyond the allowed memory!!!!

// cc -g -O0 -Wall -Wextra -Werror 13.c
// valgrind --leak-check=full --track-origins=yes --show-leak-kinds=all ./a.out

//static size_t	ft_printnstr(const char *str, va_arg(args, void*), size_t n);

int	ft_printf(const char *str0, ...);

/*
	These functions return the number of characters printed (not including
	the trailing `\0' used to end output to strings) or a negative value if
	an output error occurs, except for snprintf() and vsnprintf(), which
	return the number of characters that would have been printed if the n
	were unlimited (again, not including the final `\0').
*/
int	ft_printf(const char *str0, ...)
{
	size_t	len_r;
	va_list	args;
	char	*str;

	str = malloc(ft_strlen(str0) * sizeof(char));
	if (!str)
		return (-1);
	ft_memcpy(str, str0, ft_strlen(str0) + 1);
	va_start(args, str0);
	len_r = ft_printf_logic(str, args);
	free(str);
	return ((int) len_r);
}

// #include <stdio.h>
// #include <stdlib.h>

/**
int main() {
    void *ptr = (void *)0x7ffeefbff5a0;       // Non-null pointer for general testing
    void *null_ptr = NULL;                     // NULL pointer edge case
    int var = 42;                              // Address of variable

    printf("Normal pointer values:\n");

    // Case 1: Basic pointer without width or flags
    ft_printf("%%p: |%p|\n", ptr);
    printf("%%p: |%p|\n", ptr);

    // Case 2: Pointer with minimum field width (10)
    ft_printf("%%10p: |%10p|\n", ptr);
    printf("%%10p: |%10p|\n", ptr);

    // Case 3: Pointer with width and left-justify (`-` flag)
    ft_printf("%%-10p: |%-10p|\n", ptr);
    printf("%%-10p: |%-10p|\n", ptr);

    // Case 4: Pointer with width and zero-padding (`0` flag)
    ft_printf("%%010p: |%010p|\n", ptr);
    printf("%%010p: |%010p|\n", ptr);

    printf("\nTesting NULL pointer values:\n");

    // Case 5: NULL pointer with basic format
    ft_printf("%%p (NULL): |%p|\n", null_ptr);
    printf("%%p (NULL): |%p|\n", null_ptr);

    // Case 6: NULL pointer with width
    ft_printf("%%10p (NULL): |%10p|\n", null_ptr);
    printf("%%10p (NULL): |%10p|\n", null_ptr);

    // Case 7: NULL pointer with width and left-justify (`-` flag)
    ft_printf("%%-10p (NULL): |%-10p|\n", null_ptr);
    printf("%%-10p (NULL): |%-10p|\n", null_ptr);

    // Case 8: NULL pointer with width and zero-padding (`0` flag)
    ft_printf("%%010p (NULL): |%010p|\n", null_ptr);
    printf("%%010p (NULL): |%010p|\n", null_ptr);

    printf("\nEdge Case Testing:\n");

    // Case 9: Address of a local variable
    ft_printf("%%p (variable address): |%p|\n", &var);
    printf("%%p (variable address): |%p|\n", &var);

    // Case 10: Pointer with large width to test field expansion
    ft_printf("%%20p: |%20p|\n", ptr);
    printf("%%20p: |%20p|\n", ptr);

    // Case 11: NULL pointer with large width
    ft_printf("%%20p (NULL): |%20p|\n", null_ptr);
    printf("%%20p (NULL): |%20p|\n", null_ptr);

    // Case 12: Left-justify with large width
    ft_printf("%%-20p: |%-20p|\n", ptr);
    printf("%%-20p: |%-20p|\n", ptr);

    // Case 13: Zero-padding with large width (implementation-dependent behavior)
    ft_printf("%%020p: |%020p|\n", ptr);
    printf("%%020p: |%020p|\n", ptr);

    return 0;
}
/**/


/*
int main(void) {
    // Test with UINT_MAX - largest value for unsigned int
    ft_printf("%%u: |%u|\n", 4294967295U);
    printf("%%u: |%u|\n", 4294967295U);

    // Test with UINT_MAX - 1 (just below max boundary)
    ft_printf("%%u: |%u|\n", 4294967294U);
    printf("%%u: |%u|\n", 4294967294U);

    // Very large width with smaller number
    ft_printf("%%100u: |%100u|\n", 12345);
    printf("%%100u: |%100u|\n", 12345);

    // Width with zero padding, larger number
    ft_printf("%%020u: |%020u|\n", 1234567890);
    printf("%%020u: |%020u|\n", 1234567890);

    // Left-justify with large width, ensuring no padding
    ft_printf("%%-50u: |%-50u|\n", 123);
    printf("%%-50u: |%-50u|\n", 123);

    // Large number with left justification and width
    ft_printf("%%-30u: |%-30u|\n", 4294967295U);
    printf("%%-30u: |%-30u|\n", 4294967295U);

    // Right-justify with width smaller than the number's length
    ft_printf("%%5u: |%5u|\n", 123456789);
    printf("%%5u: |%5u|\n", 123456789);

    // Test with unsupported flag combinations: left-align and zero padding (mutually exclusive)
    ft_printf("%%-010u: |%-010u|\n", 123);
    printf("%%-010u: |%-010u|\n", 123);

    return 0;
}
/**/

/*
int main(void)
{
    // Test 1: Basic unsigned integer
    ft_printf("%%u: |%u|\n", 42);
    printf("%%u: |%u|\n", 42);

    // Test 2: Zero value
    ft_printf("%%u: |%u|\n", 0);
    printf("%%u: |%u|\n", 0);

    // Test 3: Large unsigned integer (close to UINT_MAX)
    ft_printf("%%u: |%u|\n", 4294967295U);
    printf("%%u: |%u|\n", 4294967295U);

    // Test 4: Width specified, no zero padding
    ft_printf("%%u: |%10u|\n", 123);
    printf("%%u: |%10u|\n", 123);

    // Test 5: Width with zero padding
    ft_printf("%%u: |%010u|\n", 123);
    printf("%%u: |%010u|\n", 123);

    // Test 6: Width smaller than number length
    ft_printf("%%u: |%2u|\n", 123456);
    printf("%%u: |%2u|\n", 123456);

    // Test 7: Large width
    ft_printf("%%u: |%20u|\n", 12345);
    printf("%%u: |%20u|\n", 12345);

    // Test 8: Left-justified with width
    ft_printf("%%u: |%-10u|\n", 123);
    printf("%%u: |%-10u|\n", 123);

    // Test 9: Zero with width and zero-padding
    ft_printf("%%u: |%010u|\n", 0);
    printf("%%u: |%010u|\n", 0);

    // Test 10: Very large number with width and padding
    ft_printf("%%u: |%25u|\n", 4294967295U);
    printf("%%u: |%25u|\n", 4294967295U);

    return 0;
}
/**/

/*
int main() {
    int value = 0x1A3;

    // Minimum width and precision with non-zero value
    ft_printf("|%%1x|: |%1X|\n", value);
    printf("|%%1x|: |%1x|\n", value);

    ft_printf("|%%1.1x|: |%1.1x|\n", value);
    printf("|%%1.1x|: |%1.1x|\n", value);

    // // Edge cases with width and precision with value 0
    ft_printf("|%%#.0x|: |%#.0x|\n", 0);
    printf("|%%#.0x|: |%#.0x|\n", 0);

    ft_printf("|%%5.0x|: |%5.0x|\n", 0);
    printf("|%%5.0x|: |%5.0x|\n", 0);

    ft_printf("|%%#5.0x|: |%#5.0x|\n", 0);
    printf("|%%#5.0x|: |%#5.0x|\n", 0);

    // // Combinations of flags #, 0, -, and precision with small widths
    ft_printf("|%%#3x|: |%#3x|\n", value);
    printf("|%%#3x|: |%#3x|\n", value);

    ft_printf("|%%-3x|: |%-3x|\n", value);
    printf("|%%-3x|: |%-3x|\n", value);

    // // Testing %X to ensure uppercase hexadecimal output
    ft_printf("|%%#X|: |%#X|\n", value);
    printf("|%%#X|: |%#X|\n", value);

    ft_printf("|%%#08.5X|: |%#08.5X|\n", value);
    printf("|%%#08.5X|: |%#08.5X|\n", value);

    // // Combination of - and width with small precision
    ft_printf("|%%-8.2x|: |%-8.2x|\n", value);
    printf("|%%-8.2x|: |%-8.2x|\n", value);

    // // 0 flag combined with different width and precision values
    ft_printf("|%%010.3x|: |%010.3x|\n", value);
    printf("|%%010.3x|: |%010.3x|\n", value);

    return 0;
}
/**/

/*
int main() {
    int value = 0x1A3; // Example value in hexadecimal (419 in decimal)

    // No flags, no width, no precision
    // printf("1. No flags, no width, no precision: |%x|\n", value);          // Expected: "1a3"
	ft_printf("|%%x|: |%x|\n", value);
	printf("|%%x|: |%x|\n", value);

    // No flags, width, no precision
    // printf("2. Width 8: |%8x|\n", value);                                  // Expected: "     1a3"
	ft_printf("|%%8x|: |%8x|\n", value);
	printf("|%%8x|: |%8x|\n", value);

    // No flags, no width, precision 5
    // printf("3. Precision 5: |%.5x|\n", value);                             // Expected: "001a3"
	ft_printf("|%%.5x|: |%.5x|\n", value);
	printf("|%%.5x|: |%.5x|\n", value);

    // No flags, width 8, precision 5
    // printf("4. Width 8, Precision 5: |%8.5x|\n", value);                   // Expected: "   001a3"
    ft_printf("|%%0.5x|: |%0.5x|\n", value);                   // Expected: "   001a3"
	printf("|%%0.5x|: |%0.5x|\n", value);                   // Expected: "   001a3"

	ft_printf("|%%8.5x|: |%8.5x|\n", value);                   // Expected: "   001a3"
	printf("|%%8.5x|: |%8.5x|\n", value);                   // Expected: "   001a3"

	ft_printf("|%%8.0x|: |%8.0x|\n", value);                   // Expected: "   001a3"
	printf("|%%8.0x|: |%8.0x|\n", value);                   // Expected: "   001a3"

	ft_printf("|%%8.x|: |%8.x|\n", value);                   // Expected: "   001a3"
	printf("|%%8.x|: |%8.x|\n", value);                   // Expected: "   001a3"

	ft_printf("|%%.x|: |%.x|\n", value);                   // Expected: "   001a3"
	printf("|%%.x|: |%.x|\n", value);                   // Expected: "   001a3"

    // # flag, no width, no precision
    // printf("5. # flag: |%#x|\n", value);                                   // Expected: "0x1a3"
    ft_printf("|%%#x|: |%#x|\n", value);                                   // Expected: "0x1a3"
    printf("|%%#x|: |%#x|\n", value);                                   // Expected: "0x1a3ft_"


    // # flag, width 8, no precision
    // printf("6. # flag, width 8: |%#8x|\n", value);                         // Expected: "   0x1a3"
    ft_printf("|%%#8x|: |%#8x|\n", value);                         // Expected: "   0x1a3"
    printf("|%%#8x|: |%#8x|\n", value);                         // Expected: "   0x1a3ft_"

    // # flag, no width, precision 5
    // printf("7. # flag, precision 5: |%#.5x|\n", value);                    // Expected: "0x001a3"
    ft_printf("|%%#.5x|: |%#.5x|\n", value);                    // Expected: "0x001a3"
    printf("|%%#.5x|: |%#.5x|\n", value);                    // Expected: "0x001a3ft_"


    // # flag, width 8, precision 5
    // printf("8. # flag, width 8, precision 5: |%#8.5x|\n", value);          // Expected: " 0x001a3"
    ft_printf("|%%#8.5x|: |%#8.5x|\n", value);          // Expected: " 0x001a3"
    printf("|%%#8.5x|: |%#8.5x|\n", value);          // Expected: " 0x001a3ft_"

    // 0 flag, width 8, no precision
    // printf("9. 0 flag, width 8: |%08x|\n", value);                         // Expected: "000001a3"
    ft_printf("|%%08x|: |%08x|\n", value);                         // Expected: "000001a3"
    printf("|%%08x|: |%08x|\n", value);                         // Expected: "000001a3ft_"

    // 0 flag, width 8, precision 5 (0 ignored due to precision)
    // printf("10. 0 flag, width 8, precision 5: |%08.5x|\n", value);         // Expected: "   001a3"
    ft_printf("|%%08.5x| |%08.5x|\n", value);         // Expected: "   001a3"
    printf("|%%08.5x| |%08.5x|\n", value);         // Expected: "   001a3ft_"


    // - flag, width 8, no precision
    // printf("11. - flag, width 8: |%-8x|\n", value);                        // Expected: "1a3     "
    ft_printf("|%%-8x|: |%-8x|\n", value);                        // Expected: "1a3     "
    printf("|%%-8x|: |%-8x|\n", value);                        // Expected: "1a3     ft_"

    // - flag, width 8, precision 5
    // printf("12. - flag, width 8, precision 5: |%-8.5x|\n", value);         // Expected: "001a3   "
    ft_printf("|%%-8.5x|: |%-8.5x|\n", value);         // Expected: "001a3   "
    printf("|%%-8.5x|: |%-8.5x|\n", value);         // Expected: "001a3   "

 // # and 0 flags, width 8, no precision
    // printf("13. # and 0 flags, width 8: |%#08x|\n", value);                // Expected: "0x0001a3"
    ft_printf("|%%#08x|: |%#08x|\n", value);                // Expected: "0x0001a3"
    printf("|%%#08x|: |%#08x|\n", value);                // Expected: "0x0001a3"
// |   001a3|
    // # and 0 flags, width 8, precision 5 (precision overrides 0)
    // printf("14. # and 0 flags, width 8, precision 5: |%#08.5x|\n", value); // Expected: " 0x001a3"
    ft_printf("|%%#08.5x|: |%#08.5x|\n", value); // Expected: " 0x001a3"
    printf("|%%#08.5x|: |%#08.5x|\n", value); // Expected: " 0x001a3"

    // # and - flags, width 8, no precision
    // printf("15. # and - flags, width 8: |%#-8x|\n", value);                // Expected: "0x1a3   "
    ft_printf("|%%#-8x|: |%#-8x|\n", value);                // Expected: "0x1a3   "
    printf("|%%#-8x|: |%#-8x|\n", value);                // Expected: "0x1a3   "

    // # and - flags, width 8, precision 5
    // printf("16. # and - flags, width 8, precision 5: |%#-8.5x|\n", value); // Expected: "0x001a3 "
    ft_printf("|%%#-8.5x|: |%#-8.5x|\n", value); // Expected: "0x001a3 "
    printf("|%%#-8.5x|: |%#-8.5x|\n", value); // Expected: "0x001a3 "

	ft_printf("|%%#-8.2x|: |%#-8.2x|\n", value); // Expected: "0x001a3 "
    printf("|%%#-8.2x|: |%#-8.2x|\n", value); // Expected: "0x001a3 "

    // Precision .0 and value zero (special case)
    // printf("17. Precision .0, value zero: |%.0x|\n", 0);                   // Expected: ""
    ft_printf("|%%.0x|: |%.0x|\n", 0);                   // Expected: ""
    printf("|%%.0x|: |%.0x|\n", 0);                   // Expected: ""

    // # flag, precision .0, value zero (no 0x prefix shown for zero)
    // printf("18. # flag, precision .0, value zero: |%#.0x|\n", 0);          // Expected: ""
    ft_printf("|%%#.0x|: |%#.0x|\n", 0);          // Expected: ""
	printf("|%%#.0x|: |%#.0x|\n", 0);          // Expected: ""

	ft_printf("|%%#0.0x|: |%#0.0x|\n", 0);          // Expected: ""
	printf("|%%#0.0x|: |%#0.0x|\n", 0);          // Expected: ""

	ft_printf("|%%#.x|: |%#.x|\n", 0);          // Expected: ""
	printf("|%%#.x|: |%#.x|\n", 0);          // Expected: ""

	ft_printf("|%%#0.x|: |%#0.x|\n", 0);          // Expected: ""
	printf("|%%#0.x|: |%#0.x|\n", 0);          // Expected: ""

	return 0;
}
/**/

/*
int main() {
	ft_printf("Test 1: %-%s\n");
	printf("Test 1: %-%s\n");

	return (0);
}
/**/

/*
int main() {
    // Basic integer tests without flags
    ft_printf("Test 1: %%d with 123: |%d|\n", 123);          // Expected: |123|
	printf("Test 1: %%d with 123: |%d|\n", 123);          // Expected: |123|

    ft_printf("Test 2: %%i with 123: |%i|\n", 123);          // Expected: |123|
	printf("Test 2: %%i with 123: |%i|\n", 123);          // Expected: |123|

	ft_printf("Test 3: %%d with -123: |%d|\n", -123);        // Expected: |-123|
    printf("Test 3: %%d with -123: |%d|\n", -123);        // Expected: |-123|

	ft_printf("Test 4: %%i with -123: |%i|\n", -123);        // Expected: |-123|
    printf("Test 4: %%i with -123: |%i|\n", -123);        // Expected: |-123|

	ft_printf("Test 5: %%d with 0: |%.3d|\n", 0);              // Expected: |0|
	printf("Test 5: %%d with 0: |%.3d|\n", 0);              // Expected: |0|

	ft_printf("Test 6: %%i with 0: |%i|\n", 0);              // Expected: |0|
	printf("Test 6: %%i with 0: |%i|\n", 0);              // Expected: |0|

	// Tests with flags
    ft_printf("Test 7: %%+d with 123: |%+d|\n", 123);        // Expected: |+123|
    printf("Test 7: %%+d with 123: |%+d|\n", 123);        // Expected: |+123|

	ft_printf("Test 8: %%+d with -123: |%+d|\n", -123);      // Expected: |-123|
    printf("Test 8: %%+d with -123: |%+d|\n", -123);      // Expected: |-123|

	ft_printf("Test 9: %% d with 123: |% d|\n", 123);        // Expected: | 123|
    printf("Test 9: %% d with 123: |% d|\n", 123);        // Expected: | 123|

	ft_printf("Test 10: %% d with -123: |% d|\n", -123);     // Expected: |-123|
    printf("Test 10: %% d with -123: |% d|\n", -123);     // Expected: |-123|

	ft_printf("Test 11: %%05d with 123: |%05d|\n", 123);     // Expected: |00123|
    printf("Test 11: %%05d with 123: |%05d|\n", 123);     // Expected: |00123|


	ft_printf("Test 11: %%05d with 123: |% 05d|\n", 123);     // Expected: | 0123| // correct
    printf("Test 11: %%05d with 123: |% 05d|\n", 123);     // Expected: | 0123|

	ft_printf("Test 11: %%05d with +123: |% +06d|\n", 123);     // Expected: |00123| // bad
	printf("Test 11: %%05d with +123: |% +06d|\n", 123);     // Expected: |00123|

	ft_printf("Test 11: %%05d with -123: |% 05d|\n", -123);     // Expected: |00123| // bad
	printf("Test 11: %%05d with -123: |% 05d|\n", -123);     // Expected: |00123|


	ft_printf("Test 12: %%05d with -123: |%05d|\n", -123);   // Expected: |-0123| // correct
    printf("Test 12: %%05d with -123: |%05d|\n", -123);   // Expected: |-0123|

	ft_printf("Test 12: %%05d with -123: |% 05d|\n", -123);   // Expected: |-0123|
    printf("Test 12: %%05d with -123: |% 05d|\n", -123);   // Expected: |-0123|

	ft_printf("Test 12: %%05d with -123: |% 0d|\n", -123);   // Expected: |-0123|
    printf("Test 12: %%05d with -123: |% 0d|\n", -123);   // Expected: |-0123|

	ft_printf("Test 12: %%05d with -123: |% 0d|\n", 1);
	printf("Test 12: %%05d with -123: |% 0d|\n", 1);


	ft_printf("Test 12: %%05d with -123: |%0d|\n", 1);
	printf("Test 12: %%05d with -123: |%0d|\n", 1);

	printf("|%08.5d|\n", -123);
	ft_printf("|%08.5d|\n", -123);

	ft_printf("|%08.d|\n", -123);
	printf("|%08.d|\n", -123);

	ft_printf("|%07.5d|\n", -123);
	printf("|%07.5d|\n", -123);

	ft_printf("Test 13: %%-5d with 123: |%-5d|\n", 123);     // Expected: |123  |
    printf("Test 13: %%-5d with 123: |%-5d|\n", 123);     // Expected: |123  |


	ft_printf("Test 14: %%-5d with -123: |%-5d|\n", -123);   // Expected: |-123 |
	printf("Test 14: %%-5d with -123: |%-5d|\n", -123);   // Expected: |-123 |
	/////////////
    // Tests with width and precision
    ft_printf("Test 15: %%8d with 123: |%8d|\n", 123);       // Expected: |     123|
	printf("Test 15: %%8d with 123: |%8d|\n", 123);       // Expected: |     123|

	ft_printf("Test 16: %%8d with -123: |%8d|\n", -123);     // Expected: |    -123|	bad
    printf("Test 16: %%8d with -123: |%8d|\n", -123);     // Expected: |    -123|

	ft_printf("Test 17: %%.2d with 123: |%.2d|\n", 123);     // Expected: |123|
    printf("Test 17: %%.2d with 123: |%.2d|\n", 123);     // Expected: |123|

	ft_printf("Test 18: %%.2d with -123: |%.2d|\n", -123);   // Expected: |-123|
    printf("Test 18: %%.2d with -123: |%.2d|\n", -123);   // Expected: |-123|


	ft_printf("Test 19: %%.5d with 123: |%.5d|\n", 123);     // Expected: |00123|
    printf("Test 19: %%.5d with 123: |%.5d|\n", 123);     // Expected: |00123|

	ft_printf("Test 20: %%.5d with -123: |%.5d|\n", -123);   // Expected: |-00123|
    printf("Test 20: %%.5d with -123: |%.5d|\n", -123);   // Expected: |-00123|

	ft_printf("Test 21: %%8.5d with 123: |%8.5d|\n", 123);   // Expected: |   00123|
    printf("Test 21: %%8.5d with 123: |%8.5d|\n", 123);   // Expected: |   00123|

	ft_printf("Test 22: %%8.5d with -123: |%8.5d|\n", -123); // Expected: |  -00123|
	printf("Test 22: %%8.5d with -123: |%8.5d|\n", -123); // Expected: |  -00123|

    // Edge cases with zero
    ft_printf("Test 23: %%+d with 0: |%+d|\n", 0);           // Expected: |+0|
    printf("Test 23: %%+d with 0: |%+d|\n", 0);           // Expected: |+0|


	ft_printf("Test 24: %% d with 0: |% d|\n", 0);           // Expected: | 0|
    printf("Test 24: %% d with 0: |% d|\n", 0);           // Expected: | 0|
	//
	ft_printf("Test 25: %%05d with 0: |%05d|\n", 0);         // Expected: |00000|
    printf("Test 25: %%05d with 0: |%05d|\n", 0);         // Expected: |00000|
	//
	ft_printf("Test 26: %%.0d with 0: |%.0d|\n", 0);         // Expected: ||
    printf("Test 26: %%.0d with 0: |%.0d|\n", 0);         // Expected: ||

	ft_printf("Test 27: %%5.0d with 0: |%5.0d|\n", 0);       // Expected: |     |
	printf("Test 27: %%5.0d with 0: |%5.0d|\n", 0);       // Expected: |     |

    // Width and flag combinations
    ft_printf("Test 28: %%+8d with 123: |%+8d|\n", 123);     // Expected: |    +123| bad
    printf("Test 28: %%+8d with 123: |%+8d|\n", 123);     // Expected: |    +123|


	ft_printf("Test 29: %%+8d with -123: |%+8d|\n", -123);   // Expected: |    -123|
    printf("Test 29: %%+8d with -123: |%+8d|\n", -123);   // Expected: |    -123|

	ft_printf("Test 30: %% 8d with 123: |% 8d|\n", 123);     // Expected: |     123|
	printf("Test 30: %% 8d with 123: |% 8d|\n", 123);     // Expected: |     123|

	ft_printf("Test 31: %% 8d with -123: |% 8d|\n", -123);   // Expected: |    -123|
	printf("Test 31: %% 8d with -123: |% 8d|\n", -123);   // Expected: |    -123|

    // Combinations of flags
    ft_printf("Test 32: %%-08d with 123: |%-08d|\n", 123);   // Expected: |123     |
    printf("Test 32: %%-08d with 123: |%-08d|\n", 123);   // Expected: |123     |

	ft_printf("Test 33: %%-08d with -123: |%-08d|\n", -123); // Expected: |-123    |
    printf("Test 33: %%-08d with -123: |%-08d|\n", -123); // Expected: |-123    |

	ft_printf("Test 34: %%+ d with 123: |%+ d|\n", 123);     // Expected: |+123|
	printf("Test 34: %%+ d with 123: |%+ d|\n", 123);     // Expected: |+123|

    return 0;
}
/*

/*
int main() {

	// ft_printf("Test 11: %%05d with 123: |%05d|\n", 123);     // Expected: |00123|	fixed
    // ft_printf("Test 12: %%05d with -123: |%05d|\n", -123);   // Expected: |-0123|	fixed
    // ft_printf("Test 14: %%-5d with -123: |%-5d|\n", -123);   // Expected: |-123 |	fixed

	// ft_printf("Test 14: %%-d with -123: |%-d|\n", 123);

	// ft_printf("Test 16: %%8d with -123: |%8d|\n", -123);     // Expected: |    -123| |.....-123|	bad

    // ft_printf("\n");
	// ft_printf("Test 20: %%.5d with -123: |%.5d|\n", -123);   // Expected: |-00123|		|00-123| bad
    // ft_printf("Test 22: %%8.5d with -123: |%8.5d|\n", -123); // Expected: |  -00123|	|...00-123| bad
	// ft_printf("\n");
    // // Edge cases with zero
    // ft_printf("Test 23: %%+d with 0: |%+d|\n", 0);           // Expected: |+0|		bad
    // ft_printf("Test 24: %% d with 0: |% d|\n", 0);           // Expected: | 0|		bad
    // ft_printf("Test 25: %%05d with 0: |%05d|\n", 0);         // Expected: |00000|	bad
    // ft_printf("\n");
	// ft_printf("Test 26: %%.0d with 0: |%.0d|\n", 0);         // Expected: ||		good
    // ft_printf("Test 27: %%5.0d with 0: |%5.0d|\n", 0);       // Expected: |     |	bad
	// ft_printf("Test 33: %%-08d with -123: |%-08d|\n", -123); // Expected: |-123    | |-123.....| bad



    // Basic integer tests without flags
    // ft_printf("Test 1: %%d with 123: |%d|\n", 123);          // Expected: |123|
    // ft_printf("Test 2: %%i with 123: |%i|\n", 123);          // Expected: |123|
    // ft_printf("Test 3: %%d with -123: |%d|\n", -123);        // Expected: |-123|
    // ft_printf("Test 4: %%i with -123: |%i|\n", -123);        // Expected: |-123|
    // ft_printf("Test 5: %%d with 0: |%d|\n", 0);              // Expected: |0|		// fixed
    // ft_printf("Test 6: %%i with 0: |%i|\n", 0);              // Expected: |0|		// fixed
	// ft_printf("\n");
    // // Tests with flags
    // ft_printf("Test 7: %%+d with 123: |%+d|\n", 123);        // Expected: |+123|
    // ft_printf("Test 8: %%+d with -123: |%+d|\n", -123);      // Expected: |-123|
    // ft_printf("Test 9: %% d with 123: |% d|\n", 123);        // Expected: | 123|
    // ft_printf("Test 10: %% d with -123: |% d|\n", -123);     // Expected: |-123|
	// ft_printf("\n");
    // ft_printf("Test 11: %%05d with 123: |%05d|\n", 123);     // Expected: |00123|	bad
    // ft_printf("Test 12: %%05d with -123: |%05d|\n", -123);   // Expected: |-0123|	bad
    // ft_printf("Test 13: %%-5d with 123: |%-5d|\n", 123);     // Expected: |123  |
    // ft_printf("Test 14: %%-5d with -123: |%-5d|\n", -123);   // Expected: |-123 |	bad
	// ft_printf("\n");
    // // Tests with width and precision
    // ft_printf("Test 15: %%8d with 123: |%8d|\n", 123);       // Expected: |     123| |.....123|
    // ft_printf("Test 16: %%8d with -123: |%8d|\n", -123);     // Expected: |    -123| |.....-123|	bad
    // ft_printf("Test 17: %%.2d with 123: |%.2d|\n", 123);     // Expected: |123|
    // ft_printf("Test 18: %%.2d with -123: |%.2d|\n", -123);   // Expected: |-123|
    // ft_printf("\n");

	// ft_printf("Test 19: %%.5d with 123: |%.5d|\n", 123);     // Expected: |00123|

	// ft_printf("Test 20: %%.5d with -123: |%.5d|\n", -123);   // Expected: |-00123|		|00-123| bad
	// printf("Test 20: %%.5d with -123: |%.5d|\n", -123);   // Expected: |-00123|

	// ft_printf("Test 20: %%.5d with -123: |%+.5d|\n", 123);   // Expected: |-00123|		|00-123| bad
	// printf("Test 20: %%.5d with -123: |%+.5d|\n", 123);   // Expected: |-00123|

	// ft_printf("Test 21: %%8.5d with 123: |%8.5d|\n", 123);   // Expected: |   00123|
    // ft_printf("Test 22: %%8.5d with -123: |%8.5d|\n", -123); // Expected: |  -00123|	|...00-123| bad
	// ft_printf("\n");


	// Edge cases with zero
    // ft_printf("Test 23: %%+d with 0: |%+d|\n", 0);           // Expected: |+0|		bad
    // ft_printf("Test 24: %% d with 0: |% d|\n", 0);           // Expected: | 0|		bad
    // ft_printf("Test 25: %%05d with 0: |%05d|\n", 0);         // Expected: |00000|	bad
    // ft_printf("\n");
	// ft_printf("Test 26: %%.0d with 0: |%.0d|\n", 0);         // Expected: ||		good
    // ft_printf("Test 27: %%5.0d with 0: |%5.0d|\n", 0);       // Expected: |     |	bad
	// ft_printf("\n");
    // // Width and flag combinations
    // ft_printf("Test 28: %%+8d with 123: |%+8d|\n", 123);     // Expected: |    +123| |....+123| ok
    // ft_printf("Test 29: %%+8d with -123: |%+8d|\n", -123);   // Expected: |    -123| |....-123| ok
    // ft_printf("Test 30: %% 8d with 123: |% 8d|\n", 123);     // Expected: |     123| |.....123| ok
    // ft_printf("Test 31: %% 8d with -123: |% 8d|\n", -123);   // Expected: |    -123| |....-123| ok
	// ft_printf("\n");
    // // Combinations of flags
    // ft_printf("Test 32: %%-08d with 123: |%-08d|\n", 123);   // Expected: |123     | |123.....| ok
    // ft_printf("Test 33: %%-08d with -123: |%-08d|\n", -123); // Expected: |-123    | |-123.....| bad
    // ft_printf("Test 34: %%+ d with 123: |%+ d|\n", 123);     // Expected: |+123|	 |+123| ok

    return 0;
}
*/


/*
int main(void)
{
	char	c = 'A';
	char	*name = "Alex";
	char	*name2 = "Lexis";

	// printf("number = |%02d|\n", 139);
	// ft_printf("number = |%02d|\n", 139);

	// ft_printf("|%-10.2c|\n", c);
	// printf("|%-10.2c|\n", c);
	// ft_printf("|%10.2c|\n", c);
	// printf("|%10.2c|\n", c);

	// ft_printf("|%-.2c|\n", c);
	// printf("|%-.2c|\n", c);
	// ft_printf("|%-10.c|\n", c);
	// printf("|%-10.c|\n", c);
	// ft_printf("|%-10.0c|\n", c);
	// printf("|%-10.0c|\n", c);
	// ft_printf("|%-10.02c|\n", c);
	// printf("|%-10.02c|\n", c);

	// ft_printf("|%.2c|\n", c);
	// printf("|%.2c|\n", c);
	// ft_printf("|%10.c|\n", c);
	// printf("|%10.c|\n", c);
	// ft_printf("|%10.0c|\n", c);
	// printf("|%10.0c|\n", c);
	// ft_printf("|%10.02c|\n", c);
	// printf("|%10.02c|\n", c);

	// ft_printf("|%-10.2s|\n", name);
	// printf("|%-10.2s|\n", name);

	// ft_printf("Hello %c :) %c\n", name, name);
	// printf("Hello %c :) %c\n", name, name);
	printf("Hello %-5kc my name is %k2.s my name2 is %2s :) :)\n", name, c, name);
	ft_printf("Hello %-5kc my name is %k2.s my name2 is %2s :) :)\n", name, c, name);

	printf("Hello %-5kc my name is %k2.s :)\n", c, name);
	ft_printf("Hello %-5kc my name is %k2.s :)\n", c, name);

	printf("Hello %-k5c my name is %2k.s :)\n", c, name);
	ft_printf("Hello %-k5c my name is %2k.s :)\n", c, name);

	printf("Hello %-5c my name is %k2.s :)\n", c, name);
	ft_printf("Hello %-5c my name is %k2.s :)\n", c, name);

	   printf("Hello %-5c my name is %2s :)\n", c, name);
	ft_printf("Hello %-5c my name is %2s :)\n", c, name);
	printf("\n");
	   printf("Hello %-5c my name is %2.3s :)\n", c, name);
	ft_printf("Hello %-5c my name is %2.3s :)\n", c, name);
	printf("\n");
	   printf("Hello %-5c my name is %.3s :)\n", c, name);
	ft_printf("Hello %-5c my name is %.3s :)\n", c, name);
	printf("\n");
	   printf("Hello %-5c my name is %2.s :)\n", c, name);	// 2 spaces are printed then 0 characters of name gets printed.
	ft_printf("Hello %-5c my name is %2.s :)\n", c, name);
	printf("\n");
	   printf("Hello %-5c my name is %2.0s :)\n", c, name);	// 2 spaces are printed then 0 characters of name gets printed.
	ft_printf("Hello %-5c my name is %2.0s :)\n", c, name);
	printf("\n");
	   printf("Hello %-5c my name is %2.ks :)\n", c, name);
	ft_printf("Hello %-5c my name is %2.ks :)\n", c, name);

	// Hello A     my name is    :)
	// ft_printf("Hello %s :)\n", c);
	// ft_printf("Hello %c :) %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c \n", name, name);
	// ft_printf("Hello %d :)\n", name, name);
	return (0);
}
/**/
