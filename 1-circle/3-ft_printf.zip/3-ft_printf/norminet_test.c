// size_t	hex_printf_logic(printf_form *form_found, size_t hex_len,
// 			char *flags, unsigned int ux)
// {
// 	size_t	j;
// 	size_t	len_r;
// 	char	hexnb[10];
// 	char	b;

// 	j = -1;
// 	form_found->i = -1;
// 	b = hex_margin(flags, ux);
// 	if (form_found->form == 'X')
// 		form_found->hex_ox[1] = 'X';
// 	len_r = hex_printf_prefix(form_found, hex_len, flags, ux);
// 	if (ux != 0)
// 		wint2hex(ux, (form_found->form) / 'X', 0);
// 	if (form_found->width > hex_len && flags[0] == '-')
// 		if (form_found->precision <= hex_len
// 			&& form_found->width > hex_len + b)
// 			while (++j < form_found->width - hex_len - b)
// 				len_r += write(1, " ", 1);
// 		else if (form_found->precision > hex_len
// 			&& form_found->width > hex_len + b)
// 			while (++j < form_found->width - form_found->precision - b)
// 				len_r += write(1, " ", 1);
// 	if (ux != 0)
// 		len_r += hex_len;
// 	return (len_r);
// }
